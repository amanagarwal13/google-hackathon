"""Universe Generator Agent for Alternative Timeline Creation"""

from google.adk import Agent

from . import prompt

MODEL = "gemini-2.5-pro"

universe_generator_agent = Agent(
    model=MODEL,
    name="universe_generator_agent",
    instruction=prompt.UNIVERSE_GENERATOR_PROMPT,
    output_key="universe_generation_output",
)