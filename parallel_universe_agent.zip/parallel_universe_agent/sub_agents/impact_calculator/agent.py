"""Impact Calculator Agent for Decision Impact Analysis"""

from google.adk import Agent

from . import prompt

MODEL = "gemini-2.5-pro"

impact_calculator_agent = Agent(
    model=MODEL,
    name="impact_calculator_agent",
    instruction=prompt.IMPACT_CALCULATOR_PROMPT,
    output_key="impact_calculation_output",
)


