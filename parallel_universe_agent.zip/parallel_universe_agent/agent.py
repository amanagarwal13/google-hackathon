# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Financial Parallel Universe Explorer - Sequential Pipeline Implementation"""

from google.adk.agents import SequentialAgent
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset, StdioServerParameters

from .sub_agents.timeline_analyzer.agent import timeline_analyzer_agent
from .sub_agents.universe_generator.agent import universe_generator_agent
from .sub_agents.impact_calculator.agent import impact_calculator_agent
from .sub_agents.insight_synthesizer.agent import insight_synthesizer_agent

MODEL = "gemini-2.5-pro"

# The Sequential Agent orchestrates the pipeline in order:
# 1. Timeline Analyzer - extracts financial history and decision points from Fi MCP
# 2. Universe Generator - creates alternative scenarios for each decision
# 3. Impact Calculator - calculates financial differences between actual vs alternatives
# 4. Insight Synthesizer - generates final JSON with insights and recommendations

parallel_universe_pipeline = SequentialAgent(
    name="ParallelUniversePipeline",
    sub_agents=[
        timeline_analyzer_agent,      # Step 1: Extract timeline from Fi MCP → timeline_analysis_output
        universe_generator_agent,     # Step 2: Generate alternatives → universe_generation_output  
        impact_calculator_agent,      # Step 3: Calculate impacts → impact_calculation_output
        insight_synthesizer_agent,    # Step 4: Final JSON synthesis → insight_synthesis_output
    ],
    description=(
        "Sequential pipeline that transforms financial history into a comprehensive "
        "JSON multiverse analysis showing actual decisions vs alternative timelines "
        "and their financial impacts. Provides complete analysis without user interaction."
    ),
    # The agents will run in sequence, with each agent's output becoming available 
    # to subsequent agents through state key injection
)

# For ADK tools compatibility, the root agent must be named `root_agent`
root_agent = parallel_universe_pipeline