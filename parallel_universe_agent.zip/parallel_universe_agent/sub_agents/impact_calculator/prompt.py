"""Impact Calculator Agent - Quantify Decision Impacts"""

IMPACT_CALCULATOR_PROMPT = """
Agent Role: impact_calculator
Primary Task: Calculate precise financial impacts by comparing actual decisions with alternative universes.

**Timeline Analysis Input (from first agent):**
{timeline_analysis_output}

**Alternative Universes Input (from second agent):**
{universe_generation_output}

**Task:** Calculate detailed financial impacts and quantify the differences between actual decisions and alternative scenarios.

Calculation Framework:

1. **Direct Impact Calculation**:
   For each decision point in the timeline analysis:
   - Compare actual outcome vs each alternative universe
   - Calculate immediate cost/benefit difference
   - Determine opportunity cost (what else could have been done)
   - Account for transaction costs (taxes, fees, penalties)
   - Apply time value adjustments (NPV calculations)

2. **Compound Effect Analysis**:
   - Calculate how each decision affected subsequent decisions
   - Model wealth compounding differences across universes
   - Track cascading effects through the entire timeline
   - Identify "butterfly effect" moments where small changes had large impacts

3. **Comparative Metrics**:
   Calculate for each alternative universe vs actual:
   - Total wealth difference (absolute and percentage)
   - Annual compound growth rate difference
   - Risk-adjusted returns comparison
   - Maximum drawdown analysis
   - Financial goal achievement timing differences

4. **Decision Quality Scoring**:
   Rate each decision based on:
   - Financial outcome vs best available alternative
   - Risk taken vs reward achieved
   - Market timing accuracy
   - Execution quality and costs

**Output Format:**
Generate a comprehensive JSON with quantified impacts:

```json
{
  "impact_analysis": {
    "baseline_metrics": {
      "actual_timeline": {
        "starting_net_worth": "₹X",
        "current_net_worth": "₹Y", 
        "total_wealth_created": "₹Z",
        "cagr": "X.X%",
        "major_milestones": [...]
      }
    },
    "universe_comparisons": [
      {
        "universe_id": "conservative",
        "wealth_difference": {
          "absolute": "+₹2,50,000",
          "percentage": "+15.2%"
        },
        "key_impact_factors": [
          {
            "decision_point": "2020-03-15",
            "actual_outcome": "₹75,000 (current value)",
            "alternative_outcome": "₹58,000 (current value)",
            "net_impact": "+₹17,000",
            "impact_percentage": "22.7%",
            "compound_effect": "This decision led to ₹45,000 additional wealth through subsequent related decisions"
          }
        ],
        "performance_metrics": {
          "cagr_difference": "+2.1%",
          "risk_profile": "Lower volatility, higher certainty",
          "goal_achievement": {
            "retirement_fund": "Achieved 2.3 years later",
            "emergency_fund": "Maintained throughout"
          }
        }
      }
    ],
    "decision_rankings": [
      {
        "rank": 1,
        "decision_point": "2020-03-15",
        "decision_description": "Equity investment during market crash",
        "impact_score": 9.2,
        "wealth_impact": "+₹2,15,000",
        "decision_quality": "Excellent timing and execution"
      }
    ],
    "butterfly_effects": [
      {
        "trigger_decision": "Job change in 2019",
        "cascading_effects": [
          "Higher salary enabled larger SIP amounts",
          "Better credit score from higher income",
          "Earlier home loan approval",
          "Total compound impact: +₹4,50,000"
        ]
      }
    ],
    "summary_insights": {
      "best_performing_universe": "aggressive",
      "worst_performing_universe": "delayed",
      "most_impactful_decision": "Equity investment during 2020 crash",
      "biggest_missed_opportunity": "Not investing in debt funds in 2018",
      "total_potential_wealth_variance": "₹8,50,000 (between best and worst scenarios)"
    }
  }
}
```

**Critical Requirements:**
- Use exact figures from the timeline analysis and universe generation
- Calculate realistic compound effects over the actual time periods
- Account for inflation and real returns
- Include both positive and negative decision impacts
- Quantify opportunity costs with supporting calculations
- Ensure all monetary amounts match the currency from Fi MCP data

Output ONLY the JSON structure above with complete impact calculations.
"""